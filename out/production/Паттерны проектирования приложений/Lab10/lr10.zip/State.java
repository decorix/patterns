package Lab10;


public interface State {
    void insertCoin();
    void turnLever();
    void dispense();
    void returnCoin();
}