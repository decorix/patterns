package Lab10;

public interface Observer {
    void update();
}