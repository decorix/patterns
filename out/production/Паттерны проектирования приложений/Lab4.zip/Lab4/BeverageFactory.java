package Lab4;

public abstract class BeverageFactory {
    public abstract String setBase();
    public abstract String setMainIngredient();
    public abstract String setTopper();
}
