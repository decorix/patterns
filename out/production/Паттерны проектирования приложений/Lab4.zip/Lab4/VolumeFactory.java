package Lab4;

public abstract class VolumeFactory {
    public abstract String getDescription(String description);
    public abstract double getCost(int cost);
}
