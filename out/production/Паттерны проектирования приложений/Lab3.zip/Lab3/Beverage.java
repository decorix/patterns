package Lab3;

public class Beverage {
    private String description = "";
    private int cost = 0;

    public String getDescription() {
        return description;
    }

    public int cost() {
        return cost;
    }
}
