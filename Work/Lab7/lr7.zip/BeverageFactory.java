package Lab7;

interface BeverageFactory {
    Beverage createBeverage(double volume);
}