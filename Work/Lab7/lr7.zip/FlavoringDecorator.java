package Lab7;

abstract class FlavoringDecorator extends Beverage {
    public abstract String getDescription();
}